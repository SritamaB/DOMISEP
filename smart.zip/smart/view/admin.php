
<html>
<head>
<meta charset="utf-8">
<title>Smart Home Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://webthemez.com" />
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<link href="css/register.css" rel="stylesheet" />
</head>
<body>
<div id="wrapper">
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><p></P></a>
					<a class="navbar-brand" href="index.html"><img src="img/logo.png" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
				    <li clas="active"><a href="index.php">Home</a></li>
                        <li clas="active"><a href="about.html">About Us</a></li>
                        <li clas="active"><a href="faq.html">FAQ</a></li>
						<li><a href="login.html">Login</a></li>
						<li><a href="signup.php">Sign-Up</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>


<form action="dashboard.html">
  <div class="container">
  <div class="col-md-offset-3 col-md-6">
  <h2>Admin Login</h2>
  <hr />
  <p><b>User Name:</b></p>
    <input type="text"  name="name" required>
	<p><b>Password:</b></p>
    <input type="password" name="pass" required>
	<br>
	<br>
	<br>
    <div class="clearfix">
      <p>If you don't have an account please register <a href="signup.html">here</a></p>
      <button type="submit" class="btn btn-success btn-md col-md-3 pull-right">Login</button>
    </div>
	<br>
	<br>
	<br>
	<br>
	<br>
  </div>
  </div>
</form>
 	
</html>