<?php 

    
    
    if (isset($_POST['submit']))
        {     
    include("config.php");
    session_start();
    $email = $_POST['mail'];
$pass = $_POST['pass'];
    $_SESSION['login_user']=$email; 
    $query1 = "SELECT EmailID FROM user WHERE EmailID='$email' and Password='$pass'";
        $query2=mysqli_query($dbcon,$query1);
        $query3= mysqli_num_rows($query2);
        
     if ($query3!= 0)
    {
     header("Location:../view/index2.html");
      }
      else{
      
    echo "<script type='text/javascript'>alert('User Name Or Password Invalid!')</script>";
          
          //header("Location:../view/login.html")
          //echo<meta http-equiv="refresh" content="5;URL='http://localhost/smart/view/login.php'">;
          //header( "Refresh:5; url=http://localhost/smart/view/login.php");
       // header(<meta http-equiv="refresh" content=5;URL='http://localhost/smart/view/login.php'>");
      }
    }
    ?>
