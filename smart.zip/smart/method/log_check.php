<?php 
include_once("config.php");

$email = $_POST['mail'];
$pass = $_POST['Pass'];

$result = "Select * From user where EmailID='$Mail' AND Password='$Pass'";

$req = mysql_query($result);
$log= mysql_fetch_array($req);


	
	if(($log['mail']== $mail && $pass['pass']== $pass) && ($mail!="" && $pass!="")){

		
		echo "wrong user";

}

	elseif(($log['mail']!= $mail || $log['pass']!= $pass) || ($mail=="" || $Pass=="")){		
        //include_once("../Controller/Login.php");
        header ('Location:index2.php');
    }
?>

